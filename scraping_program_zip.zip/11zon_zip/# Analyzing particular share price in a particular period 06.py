# Analyzing particular share price in a particular period 06
import pandas as pd
import plotly.express as px

df = pd.read_csv('G:/Data Analysis - Python/Demo/Input Program/GUI PROGRAMING/BANK HISTORICAL DATA/6/CANARABANK.csv')

fig = px.scatter(df, x='Date', y='Open', title='CANARA Stock Price 2022-2023')

fig.show()
