# BSE market data analysis - 2019-20 -( 02 )
import pandas as pd
#pip install plotly
import pandas as pd
import plotly.express as px

df = pd.read_csv('G:/Data Analysis - Python/Demo/Input Program/GUI PROGRAMING/BANK HISTORICAL DATA/2/BSEN2.csv')

fig = px.line(df, x='Date', y='Open', title='BSE Stock Price 2022-2023')
fig.show()
