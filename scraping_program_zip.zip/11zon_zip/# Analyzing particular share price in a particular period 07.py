# Analyzing particular share price in a particular period 07
import pandas as pd
import plotly.express as px

df = pd.read_csv('G:/Data Analysis - Python/Demo/Input Program/GUI PROGRAMING/BANK HISTORICAL DATA/7/FEDERALBANK.csv')

fig = px.scatter(df, x='Date', y='Open', title='FEDERAL Stock Price 2022-2023')

fig.show()
