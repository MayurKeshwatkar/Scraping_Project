# BSE market data analysis - 2021-2022
import pandas as pd
#pip install plotly
import plotly.express as px
df = pd.read_csv('G:/Data Analysis - Python/Demo/Input Program/GUI PROGRAMING/BANK HISTORICAL DATA/2/BSEN2')

fig2 = px.line(df, x='Date',y=df.columns[2:5],title='BSE Market Price Analysis 2021-2022')
fig2.show()

fig3 = px.scatter(df, x='Date',y=df.columns[2:5],title='BSE Market Price Analysis 2021-2022')
fig3.show()

fig4 = px.bar(df, x='Date',y=df.columns[2:5],title='BSE Market Price Analysis 2021-2022')
fig4.show()

