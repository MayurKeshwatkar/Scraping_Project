# Analyzing particular share price in a particular period 10
import pandas as pd
import plotly.express as px

df = pd.read_csv('G:/Data Analysis - Python/Demo/Input Program/GUI PROGRAMING/BANK HISTORICAL DATA/10/DCBBANK.csv')

fig = px.scatter(df, x='Date', y='Open', title='DCB Stock Price 2022-2023')

fig.show()
